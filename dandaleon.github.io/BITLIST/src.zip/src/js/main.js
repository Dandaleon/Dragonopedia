document.addEventListener("DOMContentLoaded", () => {
  const bar = document.querySelector(".header-bar"),
    body = document.querySelector("body");
  document
    .querySelector(".header-nav__burger")
    .addEventListener("click", () => {
      bar.classList.toggle("on");
      body.classList.toggle("overflow");
    });
  bar.addEventListener("click", () => {
    bar.classList.toggle("on");
    body.classList.toggle("overflow");
  });
});
